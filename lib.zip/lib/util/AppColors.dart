import 'package:flutter/material.dart';

class AppColors {
  static Color buttonColor = Color(0xFF000070);
  static Color addTextColor = Color(0xFF1bbe54);
  static Color cartPage = Color(0xFF324be0);
  static Color applyText = Color(0xFFff7800);
  static Color moreText = Color(0xFF056fff);
  static Color iconColor = Color(0xFF334be0);
  static Color loginButtonColor = Color(0xFF324be0);
}
