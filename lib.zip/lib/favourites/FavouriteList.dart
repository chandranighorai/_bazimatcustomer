import 'package:bazimat/util/AppColors.dart';
import 'package:flutter/material.dart';

class FavouriteList extends StatefulWidget {
  const FavouriteList({Key key}) : super(key: key);

  @override
  _FavouriteListState createState() => _FavouriteListState();
}

class _FavouriteListState extends State<FavouriteList> {
  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      Padding(
        padding: const EdgeInsets.only(
            top: 8.0, left: 8.0, right: 8.0, bottom: 12.0),
        child: Container(
          //height: MediaQuery.of(context).size.width * 0.2,
          width: MediaQuery.of(context).size.width,
          //color: Colors.amber,
          child: Row(
            children: [
              Container(
                height: MediaQuery.of(context).size.width * 0.3,
                width: MediaQuery.of(context).size.width / 3.5,
                decoration: BoxDecoration(
                    color: Colors.red,
                    image: DecorationImage(
                        image: AssetImage("images/dal_makhani.jpg"),
                        fit: BoxFit.cover)),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.02,
              ),
              Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Pocket meal 99",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: MediaQuery.of(context).size.width * 0.045),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.01,
                    ),
                    Text(
                      "Thalis, Combo, Indian, Chinese",
                      style: TextStyle(
                          color: Colors.grey,
                          fontSize: MediaQuery.of(context).size.width * 0.035),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.01,
                    ),
                    Text(
                      "Salt lake sector - v | 2.2 kms",
                      style: TextStyle(
                          color: Colors.grey,
                          fontSize: MediaQuery.of(context).size.width * 0.035),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.01,
                    ),
                    RichText(
                        softWrap: true,
                        text: TextSpan(children: [
                          WidgetSpan(
                              child: Padding(
                            padding: const EdgeInsets.only(
                                top: 3.0, bottom: 3.0, right: 3.0),
                            child: Icon(
                              Icons.star,
                              color: Colors.grey,
                              size: MediaQuery.of(context).size.width * 0.03,
                            ),
                          )),
                          TextSpan(
                              text: '3.9',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: MediaQuery.of(context).size.width *
                                      0.035)),
                          WidgetSpan(
                              child: Padding(
                            padding: const EdgeInsets.only(
                                top: 0.0, bottom: 5.0, right: 4.0, left: 4.0),
                            child: Icon(
                              Icons.circle,
                              color: Colors.grey,
                              size: MediaQuery.of(context).size.width * 0.015,
                            ),
                          )),
                          TextSpan(
                              text: '44 mins',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: MediaQuery.of(context).size.width *
                                      0.035)),
                          WidgetSpan(
                              child: Padding(
                            padding: const EdgeInsets.only(
                                top: 0.0, bottom: 5.0, right: 4.0, left: 4.0),
                            child: Icon(
                              Icons.circle,
                              color: Colors.grey,
                              size: MediaQuery.of(context).size.width * 0.015,
                            ),
                          )),
                          TextSpan(
                              text: '\u20B9200 for two',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: MediaQuery.of(context).size.width *
                                      0.035)),
                        ])),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.03,
                    ),
                    Row(
                      children: [
                        Container(
                          height: MediaQuery.of(context).size.width * 0.04,
                          width: MediaQuery.of(context).size.width / 20,
                          decoration: BoxDecoration(
                              //color: Colors.red,
                              image: DecorationImage(
                                  image: AssetImage("images/discount.png"))),
                        ),
                        Text(
                          " 60% off upto \u20B9125",
                          style: TextStyle(
                              color: Colors.grey,
                              fontSize:
                                  MediaQuery.of(context).size.width * 0.03),
                        )
                      ],
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.width * 0.01,
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
      Positioned(
          top: MediaQuery.of(context).size.width * 0.29,
          left: MediaQuery.of(context).size.width * 0.04,
          right: MediaQuery.of(context).size.width * 0.68,
          bottom: MediaQuery.of(context).size.height * 0.00,
          child: Container(
            alignment: Alignment.center,
            height: MediaQuery.of(context).size.width * 0.02,
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: AppColors.buttonColor,
                borderRadius: BorderRadius.all(
                    Radius.circular(MediaQuery.of(context).size.width * 0.01))),
            child: Text(
              "60% off".toUpperCase(),
              style:
                  TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          )),
    ]);
  }
}
